#ifndef __version_h
#define __version_h

extern char * Makefile_generated_version_string;

#endif

