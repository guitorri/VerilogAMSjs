#ifndef __vpp_h
#define __vpp_h

extern int vpp_preprocess_to_parsebuffer (char **parsebuffer, const char *input_file, const char **include_path_list);

#endif

