#ifndef __vams_parse_h
#define __vams_parse_h

extern int vams_parse (char *parsebuf, size_t parsebuf_len, int debug, int tree_print);

#endif

