#ifndef __elaborate_h
#define __elaborate_h

extern int xvpi_elaborate (void);

#endif

