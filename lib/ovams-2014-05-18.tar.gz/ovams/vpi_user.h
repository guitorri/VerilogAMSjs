#ifndef vpi_user_selection_h
#define vpi_user_selection_h

#include <vpi_user_1364-2005.h>

#define __VAMS_ENABLE__ 1
#if defined(__VAMS_ENABLE__)
	#include <vpi_user_VAMS_2_3.h>
#endif

#endif

